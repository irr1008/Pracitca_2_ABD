package lsi.ubu.servicios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import lsi.ubu.tests.TestGestionDonacionesSangre;
import lsi.ubu.util.ExecuteScript;
import lsi.ubu.util.PoolDeConexiones;

/**
 * GestionDonacionesSangre: Implementa la gestion de donaciones de sangre según
 * el enunciado del ejercicio.
 *
 * @author <a href="mailto:jmaudes@ubu.es">Jesus Maudes</a>
 * @author <a href="mailto:rmartico@ubu.es">Raul Marticorena</a>
 * @author <a href="mailto:pgdiaz@ubu.es">Pablo Garcia</a>
 * @author <a href="mailto:srarribas@ubu.es">Sandra Rodriguez</a>
 * @version 1.5
 * @since 1.0
 */
public class EsqueletoGestionDonacionesSangre {

	private static Logger logger = LoggerFactory.getLogger(EsqueletoGestionDonacionesSangre.class);

	private static final String script_path = "sql/";

	public static void main(String[] args) throws SQLException {
		tests();
		System.out.println("FIN.............");
	}

	public static void realizar_donacion(String m_NIF, int m_ID_Hospital, float m_Cantidad, Date m_Fecha_Donacion)
			throws SQLException {

		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		PreparedStatement ps_tipo_sangre = null;
		PreparedStatement ps_ultima_don = null;
		PreparedStatement ps_insert_don = null;
		PreparedStatement ps_update_res = null;
		ResultSet rs = null;

		try {
			con = pool.getConnection();

			// Validar cantidad
			if (m_Cantidad <= 0 || m_Cantidad > 0.45f) {
				throw new GestionDonacionesSangreException(
						GestionDonacionesSangreException.VALOR_CANTIDAD_DONACION_INCORRECTO);
			}

			// Obtener tipo de sangre del donante
			ps_tipo_sangre = con.prepareStatement("SELECT id_tipo_sangre FROM donante WHERE NIF = ?");
			ps_tipo_sangre.setString(1, m_NIF);
			rs = ps_tipo_sangre.executeQuery();
			if (!rs.next()) {
				throw new GestionDonacionesSangreException(GestionDonacionesSangreException.DONANTE_NO_EXISTE);
			}
			int id_tipo_sangre = rs.getInt("id_tipo_sangre");
			rs.close();
			rs = null;

			// Verificar última donación
			ps_ultima_don = con.prepareStatement(
					"SELECT fecha_donacion FROM donacion WHERE nif_donante = ? ORDER BY fecha_donacion DESC");
			ps_ultima_don.setString(1, m_NIF);
			rs = ps_ultima_don.executeQuery();
			if (rs.next()) {
				Date ultima = rs.getDate("fecha_donacion");
				if (Misc.howManyDaysBetween(m_Fecha_Donacion, ultima) < Misc.MANY_DAYS) {
					throw new GestionDonacionesSangreException(GestionDonacionesSangreException.DONANTE_EXCEDE);
				}
			}
			rs.close();
			rs = null;

			// Insertar donación
			ps_insert_don = con
					.prepareStatement("INSERT INTO donacion (id_donacion, nif_donante, cantidad, fecha_donacion) "
							+ "VALUES (seq_donacion.NEXTVAL, ?, ?, ?)");
			ps_insert_don.setString(1, m_NIF);
			ps_insert_don.setFloat(2, m_Cantidad);
			ps_insert_don.setDate(3, new java.sql.Date(m_Fecha_Donacion.getTime()));
			ps_insert_don.executeUpdate();

			// Actualizar reserva hospital
			ps_update_res = con.prepareStatement("UPDATE reserva_hospital SET cantidad = cantidad + ? "
					+ "WHERE id_tipo_sangre = ? AND id_hospital = ?");
			ps_update_res.setFloat(1, m_Cantidad);
			ps_update_res.setInt(2, id_tipo_sangre);
			ps_update_res.setInt(3, m_ID_Hospital);

			int filasActualizadas = ps_update_res.executeUpdate();
			if (filasActualizadas == 0) {
				throw new GestionDonacionesSangreException(GestionDonacionesSangreException.HOSPITAL_NO_EXISTE);
			}

			con.commit();
			logger.info("Donacion hecha correctamente");

		} catch (SQLException e) {
			if (con != null)
				con.rollback();
			logger.error(e.getMessage());
			throw e;

		} finally {
			if (rs != null)
				rs.close();
			if (ps_tipo_sangre != null)
				ps_tipo_sangre.close();
			if (ps_ultima_don != null)
				ps_ultima_don.close();
			if (ps_insert_don != null)
				ps_insert_don.close();
			if (ps_update_res != null)
				ps_update_res.close();
			if (con != null)
				con.close();
		}
	}

	public static void anular_traspaso(int m_ID_Tipo_Sangre, int m_ID_Hospital_Origen, int m_ID_Hospital_Destino,
			Date m_Fecha_Traspaso) throws SQLException {

		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;

		PreparedStatement ps_tipo = null;
		PreparedStatement ps_traspaso = null;
		PreparedStatement ps_reserva_destino = null;
		PreparedStatement ps_update_origen = null;
		PreparedStatement ps_update_destino = null;
		PreparedStatement ps_delete_traspaso = null;
		ResultSet rs = null;

		try {
			con = pool.getConnection();

			ps_tipo = con.prepareStatement("SELECT id_tipo_sangre " + "FROM tipo_sangre " + "WHERE id_tipo_sangre = ?");
			ps_tipo.setInt(1, m_ID_Tipo_Sangre);
			rs = ps_tipo.executeQuery();

			if (!rs.next()) {
				throw new GestionDonacionesSangreException(GestionDonacionesSangreException.TIPO_SANGRE_NO_EXISTE);
			}

			if (rs != null) {
				rs.close();
				rs = null;
			}

			ps_traspaso = con.prepareStatement("SELECT id_traspaso, cantidad " + "FROM traspaso "
					+ "WHERE id_tipo_sangre = ? " + "AND id_hospital_origen = ? " + "AND id_hospital_destino = ? "
					+ "AND fecha_traspaso = ?");
			ps_traspaso.setInt(1, m_ID_Tipo_Sangre);
			ps_traspaso.setInt(2, m_ID_Hospital_Origen);
			ps_traspaso.setInt(3, m_ID_Hospital_Destino);
			ps_traspaso.setDate(4, new java.sql.Date(m_Fecha_Traspaso.getTime()));
			rs = ps_traspaso.executeQuery();

			if (!rs.next()) {
				throw new GestionDonacionesSangreException(
						GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO);
			}

			int id_traspaso = rs.getInt("id_traspaso");
			float cantidad = rs.getFloat("cantidad");

			if (rs != null) {
				rs.close();
				rs = null;
			}

			ps_reserva_destino = con.prepareStatement("SELECT cantidad " + "FROM reserva_hospital "
					+ "WHERE id_tipo_sangre = ? " + "AND id_hospital = ?");
			ps_reserva_destino.setInt(1, m_ID_Tipo_Sangre);
			ps_reserva_destino.setInt(2, m_ID_Hospital_Destino);
			rs = ps_reserva_destino.executeQuery();

			if (!rs.next()) {
				throw new GestionDonacionesSangreException(
						GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO);
			}

			float reservaDestino = rs.getFloat("cantidad");

			if (reservaDestino < cantidad) {
				throw new GestionDonacionesSangreException(GestionDonacionesSangreException.VALOR_RESERVA_INCORRECTO);
			}

			if (rs != null) {
				rs.close();
				rs = null;
			}

			ps_update_origen = con.prepareStatement("UPDATE reserva_hospital " + "SET cantidad = cantidad + ? "
					+ "WHERE id_tipo_sangre = ? " + "AND id_hospital = ?");
			ps_update_origen.setFloat(1, cantidad);
			ps_update_origen.setInt(2, m_ID_Tipo_Sangre);
			ps_update_origen.setInt(3, m_ID_Hospital_Origen);

			if (ps_update_origen.executeUpdate() == 0) {
				throw new GestionDonacionesSangreException(
						GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO);
			}

			ps_update_destino = con.prepareStatement("UPDATE reserva_hospital " + "SET cantidad = cantidad - ? "
					+ "WHERE id_tipo_sangre = ? " + "AND id_hospital = ?");
			ps_update_destino.setFloat(1, cantidad);
			ps_update_destino.setInt(2, m_ID_Tipo_Sangre);
			ps_update_destino.setInt(3, m_ID_Hospital_Destino);

			if (ps_update_destino.executeUpdate() == 0) {
				throw new GestionDonacionesSangreException(
						GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO);
			}

			ps_delete_traspaso = con.prepareStatement("DELETE FROM traspaso WHERE id_traspaso = ?");
			ps_delete_traspaso.setInt(1, id_traspaso);
			ps_delete_traspaso.executeUpdate();

			con.commit();

		} catch (SQLException e) {
			if (con != null) {
				con.rollback();
			}
			logger.error(e.getMessage());
			throw e;

		} finally {
			if (rs != null)
				rs.close();
			if (ps_tipo != null)
				ps_tipo.close();
			if (ps_traspaso != null)
				ps_traspaso.close();
			if (ps_reserva_destino != null)
				ps_reserva_destino.close();
			if (ps_update_origen != null)
				ps_update_origen.close();
			if (ps_update_destino != null)
				ps_update_destino.close();
			if (ps_delete_traspaso != null)
				ps_delete_traspaso.close();
			if (con != null)
				con.close();
		}
	}

	public static void consulta_traspasos(String m_Tipo_Sangre) throws SQLException {

		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		PreparedStatement ps_tipo = null;
		PreparedStatement ps_traspasos = null;
		ResultSet rs = null;

		try {
			con = pool.getConnection();

			ps_tipo = con.prepareStatement("SELECT id_tipo_sangre FROM tipo_sangre WHERE descripcion = ?");
			ps_tipo.setString(1, m_Tipo_Sangre);
			rs = ps_tipo.executeQuery();

			if (!rs.next()) {
				throw new GestionDonacionesSangreException(GestionDonacionesSangreException.TIPO_SANGRE_NO_EXISTE);
			}

			int id_tipo_sangre = rs.getInt("id_tipo_sangre");
			rs.close();
			rs = null;

			ps_traspasos = con.prepareStatement("SELECT t.id_traspaso, "
					+ "t.id_hospital_origen, ho.nombre AS hospital_origen, "
					+ "t.id_hospital_destino, hd.nombre AS hospital_destino, " + "ts.descripcion AS tipo_sangre, "
					+ "rh.cantidad AS reserva_destino, " + "t.cantidad, t.fecha_traspaso " + "FROM traspaso t "
					+ "JOIN hospital ho ON ho.id_hospital = t.id_hospital_origen "
					+ "JOIN hospital hd ON hd.id_hospital = t.id_hospital_destino "
					+ "JOIN tipo_sangre ts ON ts.id_tipo_sangre = t.id_tipo_sangre " + "LEFT JOIN reserva_hospital rh "
					+ "ON rh.id_tipo_sangre = t.id_tipo_sangre " + "AND rh.id_hospital = t.id_hospital_destino "
					+ "WHERE t.id_tipo_sangre = ? " + "ORDER BY t.id_hospital_destino, t.fecha_traspaso");

			ps_traspasos.setInt(1, id_tipo_sangre);
			rs = ps_traspasos.executeQuery();

			System.out.printf("%-4s %-4s %-20s %-4s %-20s %-10s %-10s %-8s %-12s%n", "ID", "Ori", "Hospital Origen",
					"Des", "Hospital Destino", "Tipo", "Reserva", "Cant", "Fecha");
			System.out.println(
					"----------------------------------------------------------------------------------------------------");

			boolean hayResultados = false;

			while (rs.next()) {
				hayResultados = true;
				System.out.printf("%-4d %-4d %-20s %-4d %-20s %-10s %-10.2f %-8.2f %-12s%n", rs.getInt("id_traspaso"),
						rs.getInt("id_hospital_origen"), rs.getString("hospital_origen"),
						rs.getInt("id_hospital_destino"), rs.getString("hospital_destino"), rs.getString("tipo_sangre"),
						rs.getFloat("reserva_destino"), rs.getFloat("cantidad"),
						rs.getDate("fecha_traspaso").toString());
			}

			if (!hayResultados) {
				System.out.println("No hay traspasos para el tipo de sangre: " + m_Tipo_Sangre);
			}

		} catch (SQLException e) {
			if (con != null)
				con.rollback();
			logger.error(e.getMessage());
			throw e;

		} finally {
			if (rs != null)
				rs.close();
			if (ps_tipo != null)
				ps_tipo.close();
			if (ps_traspasos != null)
				ps_traspasos.close();
			if (con != null)
				con.close();
		}
	}

	public static void creaTablas() {
		ExecuteScript.run(script_path + "gestion_donaciones_sangre.sql");
	}

	public static void tests() throws SQLException {
		// 1. Crear tablas/objetos PL/SQL necesarios
		TestGestionDonacionesSangre.init();

		// 2. Ejecutar todos los tests
		TestGestionDonacionesSangre t = new TestGestionDonacionesSangre();
		try {
			t.ejecutarTests();
			System.out.println("Todos los tests han terminado correctamente.");
		} catch (AssertionError e) {
			System.out.println("¡¡Ha fallado algún test!!");
			e.printStackTrace();
		} finally {
			TestGestionDonacionesSangre.fin();
		}
	}
}