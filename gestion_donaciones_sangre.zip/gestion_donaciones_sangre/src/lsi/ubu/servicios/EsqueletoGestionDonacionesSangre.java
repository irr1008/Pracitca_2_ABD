package lsi.ubu.servicios;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import lsi.ubu.util.ExecuteScript;
import lsi.ubu.util.PoolDeConexiones;

/**
 * GestionDonacionesSangre: Implementa la gestion de donaciones de sangre según
 * el enunciado del ejercicio
 * 
 * @author <a href="mailto:jmaudes@ubu.es">Jesus Maudes</a>
 * @author <a href="mailto:rmartico@ubu.es">Raul Marticorena</a>
 * @author <a href="mailto:pgdiaz@ubu.es">Pablo Garcia</a>
 * @author <a href="mailto:srarribas@ubu.es">Sandra Rodriguez</a>
 * @version 1.5
 * @since 1.0
 */
public class EsqueletoGestionDonacionesSangre {

	private static Logger logger = LoggerFactory.getLogger(EsqueletoGestionDonacionesSangre.class);

	private static final String script_path = "sql/";

	public static void main(String[] args) throws SQLException {
		tests();

		System.out.println("FIN.............");
	}

	public static void realizar_donacion(String m_NIF, int m_ID_Hospital, float m_Cantidad, Date m_Fecha_Donacion)
			throws SQLException {

		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		PreparedStatement ps_tipo_sangre = null;
		PreparedStatement ps_ultima_don = null;
		PreparedStatement ps_insert_don = null;
		PreparedStatement ps_update_res = null;
		ResultSet rs = null;

		try {
			con = pool.getConnection();
			// Validar cantidad sangre
			if (m_Cantidad <= 0 || m_Cantidad > 0.45f) {
				throw new GestionDonacionesSangreException(
						GestionDonacionesSangreException.VALOR_CANTIDAD_DONACION_INCORRECTO);
			}

			// Obtener tipo sangre
			ps_tipo_sangre = con.prepareStatement("SELECT id_tipo_sangre FROM donante WHERE NIF=?");
			ps_tipo_sangre.setString(1, m_NIF);
			rs = ps_tipo_sangre.executeQuery();
			if (!rs.next()) {
				throw new GestionDonacionesSangreException(GestionDonacionesSangreException.DONANTE_NO_EXISTE);
			}
			int id_tipo_sangre = rs.getInt("id_tipo_sangre");
			rs.close();
			rs = null;

			// Verificar ultima donacion
			ps_ultima_don = con.prepareStatement(
					"SELECT fecha_donacion FROM donacion WHERE nif_donante = ? ORDER BY fecha_donacion DESC");
			ps_ultima_don.setString(1, m_NIF);
			rs = ps_ultima_don.executeQuery();
			if (!rs.next()) {
				Date ultima = rs.getDate("fecha_donacion");
				if (Misc.howManyDaysBetween(m_Fecha_Donacion, ultima) < Misc.MANY_DAYS) {
					throw new GestionDonacionesSangreException(GestionDonacionesSangreException.DONANTE_EXCEDE);
				}
			}
			rs.close();
			rs = null;

			// Insert de la donacion
			ps_insert_don = con.prepareStatement(
					"INSERT INTO donacion (id_donacion, nif_donante, cantidad, fecha_donacion) values (seq_donacion.NEXTVAL, ?, ?, ?");
			ps_insert_don.setString(1, m_NIF);
			ps_insert_don.setFloat(2, m_Cantidad);
			ps_insert_don.setDate(3, new java.sql.Date(m_Fecha_Donacion.getTime()));
			rs = ps_insert_don.executeUpdate();

			// Actualizar reserva hospital
			ps_update_res = con.prepareStatement(
					"UPDATE reserva_hospital SET cantidad = cantidad + ? WHERE id_tipo_sangre = ? AND id_hospital = ?");
			ps_update_res.setFloat(1, m_Cantidad);
			ps_update_res.setInt(2, id_tipo_sangre);
			ps_update_res.setInt(3, m_ID_Hospital);
			int filasActualizadas = ps_update_res.executeUpdate();
			if (filasActualizadas == 0) {
				throw new GestionDonacionesSangreException(GestionDonacionesSangreException.HOSPITAL_NO_EXISTE);
			}
			con.commit();
			logger.info("Donacion hecha correctamente");
		} catch (SQLException e) {
			if (con != null)
				con.rollback();
			logger.error(e.getMessage());
			throw e;

		} finally {
			if (rs != null)
				rs.close();
			if (ps_tipo_sangre != null)
				ps_tipo_sangre.close();
			if (ps_ultima_don != null)
				ps_ultima_don.close();
			if (ps_insert_don != null)
				ps_insert_don.close();
			if (ps_update_res != null)
				ps_update_res.close();
			if (con != null)
				con.close();
		}

	}

	public static void anular_traspaso(int m_ID_Tipo_Sangre, int m_ID_Hospital_Origen, int m_ID_Hospital_Destino,
			Date m_Fecha_Traspaso) throws SQLException {

		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;

		try {
			con = pool.getConnection();
			// Completar por el alumno

		} catch (SQLException e) {
			// Completar por el alumno

			logger.error(e.getMessage());
			throw e;

		} finally {
			/* A rellenar por el alumno */
		}
	}

	public static void consulta_traspasos(String m_Tipo_Sangre) throws SQLException {

		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;

		try {
			con = pool.getConnection();
			// Completar por el alumno

		} catch (SQLException e) {
			// Completar por el alumno

			logger.error(e.getMessage());
			throw e;

		} finally {
			/* A rellenar por el alumno */
		}
	}

	static public void creaTablas() {
		ExecuteScript.run(script_path + "gestion_donaciones_sangre.sql");
	}

	static void tests() throws SQLException {
		creaTablas();

		PoolDeConexiones pool = PoolDeConexiones.getInstance();

		// Relatar caso por caso utilizando el siguiente procedure para inicializar los
		// datos

		CallableStatement cll_reinicia = null;
		Connection conn = null;

		try {
			// Reinicio filas
			conn = pool.getConnection();
			cll_reinicia = conn.prepareCall("{call inicializa_test}");
			cll_reinicia.execute();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		} finally {
			if (cll_reinicia != null)
				cll_reinicia.close();
			if (conn != null)
				conn.close();

		}

	}
}
