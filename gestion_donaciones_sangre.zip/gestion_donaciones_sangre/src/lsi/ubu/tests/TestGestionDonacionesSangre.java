package lsi.ubu.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import lsi.ubu.servicios.EsqueletoGestionDonacionesSangre;
import lsi.ubu.servicios.GestionDonacionesSangreException;
import lsi.ubu.util.PoolDeConexiones;

/**
 * Tests para el sistema de gestión de donaciones de sangre. Cubre los módulos
 * realizar_donacion, anular_traspaso y consulta_traspasos.
 * 
 * @author ivan ramirez, javier vargas, jaime collado
 */
public class TestGestionDonacionesSangre {

	/**
	 * Crea las tablas necesarias en la base de datos antes de ejecutar los tests.
	 */
	public static void init() throws SQLException {
		EsqueletoGestionDonacionesSangre.creaTablas();
	}

	/** No libera ningún recurso global. */
	public static void fin() {
	}

	/** Ejecuta todos los métodos de test de forma secuencial. */
	public void ejecutarTests() throws SQLException {
		testRealizarDonacion_OK_Normal();
		testRealizarDonacion_OK_CantidadMinimaPositiva();
		testRealizarDonacion_OK_CantidadMaximaLimite();
		testRealizarDonacion_Error_Cantidad();
		testRealizarDonacion_Error_CantidadNegativa();
		testRealizarDonacion_Error_CantidadJustoMayorQueMaximo();
		testRealizarDonacion_Error_HospitalNoExiste();
		testRealizarDonacion_Error_DonanteNoExiste();
		testRealizarDonacion_Error_ExcedeCupo();
		testRealizarDonacion_Error_HospitalSinReservaParaTipo();

		testAnularTraspaso_Normal();
		testAnularTraspaso_TipoSangreNoExiste();
		testAnularTraspaso_NoEncontradoPorFecha();
		testAnularTraspaso_HospitalOrigenNoExiste();
		testAnularTraspaso_HospitalDestinoNoExiste();
		testAnularTraspaso_ReservaDestinoInsuficiente();

		testConsultaTraspasosOK();
		testConsultaTraspasosSinResultados();
		testConsultaTraspasosTipoNoExiste();
	}

	/**
	 * Reinicia la base de datos al estado inicial llamando al procedimiento
	 * inicializa_test.
	 */
	private void reiniciaTest() throws SQLException {
		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		CallableStatement cll = null;
		try {
			con = pool.getConnection();
			cll = con.prepareCall("{call inicializa_test}");
			cll.execute();
			con.commit();
		} catch (SQLException e) {
			if (con != null)
				con.rollback();
			throw e;
		} finally {
			if (cll != null)
				cll.close();
			if (con != null)
				con.close();
		}
	}

	/** Devuelve la cantidad en reserva para un tipo de sangre y hospital dados. */
	private float getReserva(int idTipoSangre, int idHospital) throws SQLException {
		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = pool.getConnection();
			ps = con.prepareStatement(
					"SELECT cantidad FROM reserva_hospital WHERE id_tipo_sangre = ? AND id_hospital = ?");
			ps.setInt(1, idTipoSangre);
			ps.setInt(2, idHospital);
			rs = ps.executeQuery();
			if (rs.next()) {
				return rs.getFloat("cantidad");
			}
			return -1f;
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
	}

	/**
	 * Cuenta las donaciones que coincidan con el NIF, cantidad y fecha indicados.
	 */
	private int contarDonaciones(String nif, float cantidad, java.sql.Date fecha) throws SQLException {
		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = pool.getConnection();
			ps = con.prepareStatement(
					"SELECT COUNT(*) FROM donacion WHERE nif_donante = ? AND cantidad = ? AND fecha_donacion = ?");
			ps.setString(1, nif);
			ps.setFloat(2, cantidad);
			ps.setDate(3, fecha);
			rs = ps.executeQuery();
			rs.next();
			return rs.getInt(1);
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
	}

	/**
	 * Cuenta los traspasos que coincidan con el tipo de sangre, origen, destino y
	 * fecha indicados.
	 */
	private int contarTraspasos(int tipoSangre, int origen, int destino, java.sql.Date fecha) throws SQLException {
		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = pool.getConnection();
			ps = con.prepareStatement(
					"SELECT COUNT(*) FROM traspaso " + "WHERE id_tipo_sangre = ? AND id_hospital_origen = ? "
							+ "AND id_hospital_destino = ? AND fecha_traspaso = ?");
			ps.setInt(1, tipoSangre);
			ps.setInt(2, origen);
			ps.setInt(3, destino);
			ps.setDate(4, fecha);
			rs = ps.executeQuery();
			rs.next();
			return rs.getInt(1);
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
	}

	// TESTS METODO REALIZAR_DONACION
	/**
	 * Donación normal con datos válidos: comprueba que se registra y la reserva
	 * aumenta.
	 */
	@Test
	public void testRealizarDonacion_OK_Normal() throws SQLException {
		reiniciaTest();
		float reservaAntes = getReserva(1, 1);
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 8, 1).getTimeInMillis());
		float cantidad = 0.35f;
		EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 1, cantidad, fecha);
		assertEquals(1, contarDonaciones("12345678A", cantidad, fecha));
		assertEquals(reservaAntes + cantidad, getReserva(1, 1), 0.001f);
	}

	/** Donación con la cantidad mínima válida (0.01 litros). */
	@Test
	public void testRealizarDonacion_OK_CantidadMinimaPositiva() throws SQLException {
		reiniciaTest();
		float reservaAntes = getReserva(1, 1);
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 8, 1).getTimeInMillis());
		float cantidad = 0.01f;
		EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 1, cantidad, fecha);
		assertEquals(1, contarDonaciones("12345678A", cantidad, fecha));
		assertEquals(reservaAntes + cantidad, getReserva(1, 1), 0.001f);
	}

	/** Donación con la cantidad máxima permitida (0.45 litros). */
	@Test
	public void testRealizarDonacion_OK_CantidadMaximaLimite() throws SQLException {
		reiniciaTest();
		float reservaAntes = getReserva(1, 1);
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 8, 1).getTimeInMillis());
		float cantidad = 0.45f;
		EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 1, cantidad, fecha);
		assertEquals(1, contarDonaciones("12345678A", cantidad, fecha));
		assertEquals(reservaAntes + cantidad, getReserva(1, 1), 0.001f);
	}

	/**
	 * Error al donar con cantidad 0: se espera VALOR_CANTIDAD_DONACION_INCORRECTO.
	 */
	@Test
	public void testRealizarDonacion_Error_Cantidad() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 1, 0.0f, new java.util.Date());
			fail("Deberia lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_DONACION_INCORRECTO, e.getErrorCode());
		}
	}

	/**
	 * Error al donar con cantidad negativa: se espera
	 * VALOR_CANTIDAD_DONACION_INCORRECTO.
	 */
	@Test
	public void testRealizarDonacion_Error_CantidadNegativa() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 1, -0.10f, new java.util.Date());
			fail("Deberia lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_DONACION_INCORRECTO, e.getErrorCode());
		}
	}

	/**
	 * Error al donar con cantidad justo por encima del máximo (0.45001): se espera
	 * VALOR_CANTIDAD_DONACION_INCORRECTO.
	 */
	@Test
	public void testRealizarDonacion_Error_CantidadJustoMayorQueMaximo() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 1, 0.45001f, new java.util.Date());
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_DONACION_INCORRECTO, e.getErrorCode());
		}
	}

	/** Error al donar en un hospital inexistente: se espera HOSPITAL_NO_EXISTE. */
	@Test
	public void testRealizarDonacion_Error_HospitalNoExiste() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 999, 0.30f, new java.util.Date());
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.HOSPITAL_NO_EXISTE, e.getErrorCode());
		}
	}

	/** Error al donar con un NIF no registrado: se espera DONANTE_NO_EXISTE. */
	@Test
	public void testRealizarDonacion_Error_DonanteNoExiste() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("00000000X", 1, 0.30f, new java.util.Date());
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.DONANTE_NO_EXISTE, e.getErrorCode());
		}
	}

	/**
	 * Error cuando el donante supera el cupo permitido: se espera DONANTE_EXCEDE y
	 * la reserva no cambia.
	 */
	@Test
	public void testRealizarDonacion_Error_ExcedeCupo() throws SQLException {
		reiniciaTest();
		float reservaAntes = getReserva(1, 1);
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 0, 16).getTimeInMillis());
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 1, 0.30f, fecha);
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.DONANTE_EXCEDE, e.getErrorCode());
		}
		assertEquals(reservaAntes, getReserva(1, 1), 0.001f);
	}

	/**
	 * Error cuando el hospital no tiene reserva para el tipo de sangre del donante:
	 * se espera HOSPITAL_NO_EXISTE.
	 */
	@Test
	public void testRealizarDonacion_Error_HospitalSinReservaParaTipo() throws SQLException {
		reiniciaTest();
		try {
			// Donante tipo O (id=4), hospital 2 no tiene reserva de tipo O
			EsqueletoGestionDonacionesSangre.realizar_donacion("98989898C", 2, 0.30f,
					new java.sql.Date(new java.util.GregorianCalendar(2025, 8, 1).getTimeInMillis()));
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.HOSPITAL_NO_EXISTE, e.getErrorCode());
		}
	}

	// TESTS METODO ANULAR_TRASPASO
	/**
	 * Anulación normal de un traspaso: el registro se elimina y las reservas se
	 * ajustan correctamente.
	 */
	@Test
	public void testAnularTraspaso_Normal() throws SQLException {
		reiniciaTest();
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 0, 11).getTimeInMillis());
		float reservaOrigenAntes = getReserva(1, 1);
		float reservaDestinoAntes = getReserva(1, 2);
		EsqueletoGestionDonacionesSangre.anular_traspaso(1, 1, 2, fecha);
		assertEquals(0, contarTraspasos(1, 1, 2, fecha));
		assertEquals(reservaOrigenAntes + 2.0f, getReserva(1, 1), 0.001f);
		assertEquals(reservaDestinoAntes - 2.0f, getReserva(1, 2), 0.001f);
	}

	/**
	 * Error al anular un traspaso con tipo de sangre inexistente: se espera
	 * TIPO_SANGRE_NO_EXISTE.
	 */
	@Test
	public void testAnularTraspaso_TipoSangreNoExiste() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.anular_traspaso(999, 1, 2, new java.util.Date());
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.TIPO_SANGRE_NO_EXISTE, e.getErrorCode());
		}
	}

	/**
	 * Error al anular un traspaso que no existe para la fecha indicada: se espera
	 * VALOR_CANTIDAD_TRASPASO_INCORRECTO.
	 */
	@Test
	public void testAnularTraspaso_NoEncontradoPorFecha() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.anular_traspaso(1, 1, 2,
					new java.sql.Date(new java.util.GregorianCalendar(2000, 0, 1).getTimeInMillis()));
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO, e.getErrorCode());
		}
	}

	/**
	 * Error al anular un traspaso con hospital origen inexistente: se espera
	 * VALOR_CANTIDAD_TRASPASO_INCORRECTO.
	 */
	@Test
	public void testAnularTraspaso_HospitalOrigenNoExiste() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.anular_traspaso(1, 999, 2, new java.util.Date());
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO, e.getErrorCode());
		}
	}

	/**
	 * Error al anular un traspaso con hospital destino inexistente: se espera
	 * VALOR_CANTIDAD_TRASPASO_INCORRECTO.
	 */
	@Test
	public void testAnularTraspaso_HospitalDestinoNoExiste() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.anular_traspaso(1, 1, 999, new java.util.Date());
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO, e.getErrorCode());
		}
	}

	/**
	 * Error cuando la reserva del destino es insuficiente para absorber la
	 * devolución: se espera VALOR_RESERVA_INCORRECTO y nada cambia.
	 */
	@Test
	public void testAnularTraspaso_ReservaDestinoInsuficiente() throws SQLException {
		reiniciaTest();
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 0, 16).getTimeInMillis());
		float reservaOrigenAntes = getReserva(2, 3);
		float reservaDestinoAntes = getReserva(2, 2);
		try {
			EsqueletoGestionDonacionesSangre.anular_traspaso(2, 3, 2, fecha);
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_RESERVA_INCORRECTO, e.getErrorCode());
		}
		assertEquals(reservaOrigenAntes, getReserva(2, 3), 0.001f);
		assertEquals(reservaDestinoAntes, getReserva(2, 2), 0.001f);
		assertEquals(1, contarTraspasos(2, 3, 2, fecha));
	}

	// TESTS METODO CONSULTA_TRASPASOS
	/**
	 * Consulta de traspasos para un tipo de sangre existente con resultados: no
	 * debe lanzar excepción.
	 */
	@Test
	public void testConsultaTraspasosOK() throws SQLException {
		reiniciaTest();
		EsqueletoGestionDonacionesSangre.consulta_traspasos("Tipo A.");
	}

	/**
	 * Consulta de traspasos para un tipo de sangre existente sin traspasos
	 * registrados: no debe lanzar excepción.
	 */
	@Test
	public void testConsultaTraspasosSinResultados() throws SQLException {
		reiniciaTest();
		EsqueletoGestionDonacionesSangre.consulta_traspasos("Tipo AB.");
	}

	/**
	 * Error al consultar traspasos con un tipo de sangre inexistente: se espera
	 * TIPO_SANGRE_NO_EXISTE.
	 */
	@Test
	public void testConsultaTraspasosTipoNoExiste() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.consulta_traspasos("Tipo Z.");
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.TIPO_SANGRE_NO_EXISTE, e.getErrorCode());
		}
	}
}