package lsi.ubu.tests;

public class TestGestionDonacionesSangre {

}