package lsi.ubu.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import lsi.ubu.servicios.EsqueletoGestionDonacionesSangre;
import lsi.ubu.servicios.GestionDonacionesSangreException;
import lsi.ubu.util.PoolDeConexiones;

public class TestGestionDonacionesSangre {
	// Metodo de inicio
	public static void init() throws SQLException {
		EsqueletoGestionDonacionesSangre.creaTablas();
	}

	// Metodo de fin
	public static void fin() {
		// No liberamos ningun recurso global
	}

	// Metodos auxiliares de ayuda
	private void reiniciaTest() throws SQLException {
		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		CallableStatement cll = null;
		try {
			con = pool.getConnection();
			cll = con.prepareCall("{call inicializa_test}");
			cll.execute();
			con.commit();
		} catch (SQLException e) {
			if (con != null)
				con.rollback();
			throw e;
		} finally {
			if (cll != null)
				cll.close();
			if (con != null)
				con.close();
		}
	}

	private float getReserva(int idTipoSangre, int idHospital) throws SQLException {
		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = pool.getConnection();
			ps = con.prepareStatement(
					"SELECT cantidad FROM reserva_hospital WHERE id_tipo_sabgre = ? AND id_hospital = ?");
			ps.setInt(1, idTipoSangre);
			ps.setInt(2, idHospital);
			rs = ps.executeQuery();
			if (rs.next()) {
				return rs.getFloat("cantidad");
			}
			return -1f;
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
	}

	private int contarDonaciones(String nif, float cantidad, java.sql.Date fecha) throws SQLException{
		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = pool.getConnection();
			ps = con.prepareStatement(
					"SELECT COUNT(*) FROM donacion WHERE nif_donante = ? AND cantidad = ? AND fecha_donacion = ?");
			ps.setString(1, nif);
			ps.setFloat(2, cantidad);
			ps.setDate(3, fecha);
			rs = ps.executeQuery();
			rs.next()
			return rs.getInt(1);
		} finally {
			if (rs != null) rs.close();
			if (ps != null) ps.close();
			if (con != null) con.close();
		}
	}

	private int contarTraspasos(int tipoSangre, int origen, int destino, java.sql.Date fecha) throws SQLException {
		PoolDeConexiones pool = PoolDeConexiones.getInstance();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = ps.getConnection();
			ps = con.prepareStatement(
					"SELECT COUNT(*) FROM traspaso WHERE id_tipo_sangre = ? AND  id_hospital_origen = ? AND id_hospital_destino = ? AND fecha_traspaso = ?");
			ps.setInt(1, tipoSangre);
			ps.setInt(2, origen);
			ps.setInt(3, destino);
			ps.setDate(4, fecha);
			rs = ps.executeQuery();
			rs.next();
			return rs.getInt(1);
		} finally {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		}
	}

	/* Bateria de test del método realizar_donacion */
	@Test
	public void testRealizarDonacion_OK_Normal() throws SQLException {
		reiniciaTest();
		float reservaAntes = getReserva(1, 1);
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 8, 1).getTimeInMillis());
		float cantidad = 0.35f;
		EsqueletoGestionDonacionesSangre.realizar_donacion("123456789A", 1, cantidad, fecha);
		assertEquals(1, contarDonaciones("123456789A", cantidad, fecha));
		assertEquals(reservaAntes + cantidad, getReserva(1, 1), 0.001f);
	}

	@Test
	public void testRealizarDonacion_OK_CantidadMinimaPositiva() throws SQLException {
		reiniciaTest();
		float reservaAntes = getReserva(1, 1);
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 8, 1).getTimeInMillis());
		float cantidad = 0.01f; // > 0 y < 0.45
		EsqueletoGestionDonacionesSangre.realizar_donacion("123456789A", 1, cantidad, fecha);
		assertEquals(1, contarDonaciones("123456789A", cantidad, fecha));
		assertEquals(reservaAntes + cantidad, getReserva(1, 1), 0.001f);
	}

	@Test
	public void testRealizarDonacion_OK_CantidadMaximaLimite() throws SQLException {
		reiniciaTest();
		float reservaAntes = getReserva(1, 1);
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 8, 1).getTimeInMillis());
		float cantidad = 0.45f;
		EsqueletoGestionDonacionesSangre.realizar_donacion("123456789A", 1, cantidad, fecha);
		assertEquals(1, contarDonaciones("123456789A", cantidad, fecha));
		assertEquals(reservaAntes + cantidad, getReserva(1, 1), 0.001f);
	}

	@Test
	public void testRealizarDonacion_Error_Cantidad() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("123456789A", 1, 0.0f, new java.util.Date());
			fail("Deberia lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO, e.getErrorCode());
		}
	}

	@Test
	public void testRealizarDonacion_Error_CantidadNegativa() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("123456789A", 1, -0.10f, new java.util.Date());
			fail("Deberia lanzar GestionDonacionesSangreException");
		} catch (SQLException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO, e.getErrorCode());
		}
	}

	@Test
	public void testRealizarDonacion_Error_CantidadJustoMayorQueMaximo() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 1, 0.45001f, new java.util.Date());
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_DONACION_INCORRECTO, e.getErrorCode());
		}
	}

	@Test
	public void testRealizarDonacion_Error_HospitalNoExiste() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 999, 0.30f, new java.util.Date());
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			// Programación ofensiva: hospital inexistente → no hay reserva, por diseño
			assertEquals(GestionDonacionesSangreException.HOSPITAL_NO_EXISTE, e.getErrorCode());
		}
	}

	@Test
	public void testRealizarDonacion_Error_DonanteNoExiste() throws SQLException {
		reiniciaTest();
		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("00000000X", 1, 0.30f, new java.util.Date());
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.DONANTE_NO_EXISTE, e.getErrorCode());
		}
	}

	@Test
	public void testRealizarDonacion_Error_ExcedeCupo() throws SQLException {
		reiniciaTest();
		float reservaAntes = getReserva(1, 1);
		java.sql.Date fecha = new java.sql.Date(new java.util.GregorianCalendar(2025, 0, 16).getTimeInMillis());

		try {
			EsqueletoGestionDonacionesSangre.realizar_donacion("12345678A", 1, 0.30f, fecha);
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.DONANTE_EXCEDE, e.getErrorCode());
		}

		assertEquals(reservaAntes, getReserva(1, 1), 0.001f);
	}

	@Test
	public void testRealizarDonacion_Error_HospitalSinReservaParaTipo() throws SQLException {
		reiniciaTest();
		try {
			// Donante tipo O (id=4), hospital 2 no tiene reserva de tipo O
			EsqueletoGestionDonacionesSangre.realizar_donacion("98989898C", 2, 0.30f,
					new java.sql.Date(new java.util.GregorianCalendar(2025, 8, 1).getTimeInMillis()));
			fail("Debería lanzar GestionDonacionesSangreException");
		} catch (GestionDonacionesSangreException e) {
			assertEquals(GestionDonacionesSangreException.HOSPITAL_NO_EXISTE, e.getErrorCode());
		}
	}
	
	/** Tests de anular_traspaso */
	
    /** Caso normal: anulación correcta del traspaso 1. */
    @Test
    public void testAnularTraspaso_Normal() throws SQLException {
       
		reiniciaTest();

        java.sql.Date fecha = new java.sql.Date(
                new java.util.GregorianCalendar(2025, 0, 11).getTimeInMillis());

        float reservaOrigenAntes  = getReserva(1, 1);
        float reservaDestinoAntes = getReserva(1, 2);

        EsqueletoGestionDonacionesSangre.anular_traspaso(1, 1, 2, fecha);

        assertEquals(0, contarTraspasos(1, 1, 2, fecha));
        assertEquals(reservaOrigenAntes  + 2.0f, getReserva(1, 1), 0.001f);
        assertEquals(reservaDestinoAntes - 2.0f, getReserva(1, 2), 0.001f);
    }

    /** Extremo: tipo de sangre inexistente. */
    @Test
    public void testAnularTraspaso_TipoSangreNoExiste() throws SQLException {
       
		reiniciaTest();

        try {
            EsqueletoGestionDonacionesSangre.anular_traspaso(999, 1, 2, new java.util.Date());
            fail("Debería lanzar GestionDonacionesSangreException");
        } catch (GestionDonacionesSangreException e) {
            assertEquals(GestionDonacionesSangreException.TIPO_SANGRE_NO_EXISTE,e.getErrorCode());
        }
    }

    /** Extremo: traspaso no encontrado por fecha incorrecta. */
    @Test
    public void testAnularTraspaso_NoEncontradoPorFecha() throws SQLException {
       
		reiniciaTest();

        try {
            EsqueletoGestionDonacionesSangre.anular_traspaso(
                    1, 1, 2,
                    new java.sql.Date(new java.util.GregorianCalendar(2000, 0, 1).getTimeInMillis()));
            fail("Debería lanzar GestionDonacionesSangreException");
        } catch (GestionDonacionesSangreException e) {
            assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO, e.getErrorCode());
        }
    }

    /** Extremo: hospital origen inexistente. */
    @Test
    public void testAnularTraspaso_HospitalOrigenNoExiste() throws SQLException {
        
		reiniciaTest();

        try {
            EsqueletoGestionDonacionesSangre.anular_traspaso(1, 999, 2, new java.util.Date());
            fail("Debería lanzar GestionDonacionesSangreException");
        } catch (GestionDonacionesSangreException e) {
            assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO,e.getErrorCode());
        }
    }

    /** Extremo: hospital destino inexistente. */
    @Test
    public void testAnularTraspaso_HospitalDestinoNoExiste() throws SQLException {
        
		reiniciaTest();

        try {
            EsqueletoGestionDonacionesSangre.anular_traspaso(1, 1, 999, new java.util.Date());
            fail("Debería lanzar GestionDonacionesSangreException");
        } catch (GestionDonacionesSangreException e) {
            assertEquals(GestionDonacionesSangreException.VALOR_CANTIDAD_TRASPASO_INCORRECTO,e.getErrorCode());
        }
    }

    /**
     * Extremo importante: reserva destino insuficiente para revertir (traspaso 5).
     * Debe lanzar VALOR_RESERVA_INCORRECTO y dejar BD igual (rollback).
     */
    @Test
    public void testAnularTraspaso_ReservaDestinoInsuficiente() throws SQLException {
        
		reiniciaTest();

        java.sql.Date fecha = new java.sql.Date(
                new java.util.GregorianCalendar(2025, 0, 16).getTimeInMillis());

        float reservaOrigenAntes  = getReserva(2, 3);
        float reservaDestinoAntes = getReserva(2, 2);

        try {
            EsqueletoGestionDonacionesSangre.anular_traspaso(2, 3, 2, fecha);
            fail("Debería lanzar GestionDonacionesSangreException");
        } catch (GestionDonacionesSangreException e) {
            assertEquals(GestionDonacionesSangreException.VALOR_RESERVA_INCORRECTO, e.getErrorCode());
        }

        assertEquals(reservaOrigenAntes,  getReserva(2, 3), 0.001f);
        assertEquals(reservaDestinoAntes, getReserva(2, 2), 0.001f);
        assertEquals(1, contarTraspasos(2, 3, 2, fecha));
    }

}
